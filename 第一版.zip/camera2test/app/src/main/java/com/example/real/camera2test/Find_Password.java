package com.example.real.camera2test;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;


public class Find_Password extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find__password);
        Button bt_1 = findViewById(R.id.bt_1);//获取验证码
        Button bt_2 = findViewById(R.id.bt_2);//确认
        Button bt_3 = findViewById(R.id.bt_3);//返回
        bt_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //获取验证码
            }
        });
        bt_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //保存到数据库

                //确认修改密码
                Toast.makeText(Find_Password.this, "修改成功", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Find_Password.this, LoginActivity.class);
                startActivity(intent);
            }
        });
        bt_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //返回登陆界面
                Intent intent = new Intent(Find_Password.this, LoginActivity.class);
                startActivity(intent);
            }
        });
    }
}
