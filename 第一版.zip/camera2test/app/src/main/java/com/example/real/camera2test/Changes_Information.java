package com.example.real.camera2test;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;


public class Changes_Information extends AppCompatActivity {
    EditText edit_1 ,edit_2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_changes__information);
        Button bt_1 =  findViewById(R.id.bt_return1);
        Button bt_2 =  findViewById(R.id.bt_2);
        Button bt_5 = findViewById(R.id.bt_5);
        RadioButton bt_3 = findViewById(R.id.male);
        RadioButton bt_4 = findViewById(R.id.femle);
        edit_1 = findViewById(R.id.edit_1);
        edit_2 = findViewById(R.id.edit_2);
        bt_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //返回个人主页
                Intent intent = new Intent(Changes_Information.this, Personal.class);
                startActivity(intent);
            }
        });
        bt_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //保存修改到数据库


                //返回个人主页
                Intent intent = new Intent(Changes_Information.this, Personal.class);
                startActivity(intent);

            }
        });
        bt_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //选择男性

            }
        });
        bt_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //选择女性

            }
        });
        bt_5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //修改头像
            }
        });
    }
}
