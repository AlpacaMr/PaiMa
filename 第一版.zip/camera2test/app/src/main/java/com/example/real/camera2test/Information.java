package com.example.real.camera2test;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class Information extends AppCompatActivity {
    EditText edit_1,edit_2,edit_3,edit_4,edit_5,edit_6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_information);
        Button bt_1 = findViewById(R.id.bt_regist_save);
        Button bt_2 = findViewById(R.id.bt_regist_cancel);
        edit_1 = findViewById(R.id.et_regist_user);//手机号
        edit_2 = findViewById(R.id.et_regist_password);//密码
        edit_3 = findViewById(R.id.et_regist_againpassword);//确认密码
        edit_4 =findViewById(R.id.et_regist_fullname);//年龄
        edit_5 = findViewById(R.id.et_regist_group);//性别
        edit_6 = findViewById(R.id.et_regist_telephone);//昵称
        bt_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //保存到数据库


                // 跳转到个人主页
                Intent intent = new Intent(Information.this, Personal.class);
                startActivity(intent);
            }
        });
        bt_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //取消并跳转到登陆界面
                Intent intent = new Intent(Information.this, LoginActivity.class);
                startActivity(intent);
            }
        });
    }
}
