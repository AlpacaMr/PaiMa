package com.example.real.camera2test;

/**
 * Created by Administrator on 2018-03-19.
 */

public class UploadResult {

    /**
     * status : 1
     * msg : 提交成功
     */

    private int status;
    private String msg;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
