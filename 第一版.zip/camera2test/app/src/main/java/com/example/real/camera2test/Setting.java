package com.example.real.camera2test;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;


public class Setting extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        TextView item_detail = (TextView) findViewById(R.id.item_detail );
        item_detail.setMovementMethod(ScrollingMovementMethod.getInstance());
        Button button1 = (Button) findViewById(R.id.button1 );
        Switch st_button1=(Switch)findViewById(R.id.st_button1);
        Switch st_button2=(Switch)findViewById(R.id.st_button2);
        Button button5=(Button)super. findViewById(R.id.button5);
        Button button6=(Button)super. findViewById(R.id.button6);
        Button button7=(Button)super. findViewById(R.id.button7);
        Button button8 = (Button)findViewById(R.id.bt_8);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Setting.this, "Clicked", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Setting.this, AccountSecurity.class);
                startActivity(intent);
            }
        });
        st_button1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b){
                    Toast.makeText(Setting.this,"已开启",Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(Setting.this,"已关闭",Toast.LENGTH_SHORT).show();
                }
            }
        });
        st_button2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b){
                    Toast.makeText(Setting.this,"已开启",Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(Setting.this,"已关闭",Toast.LENGTH_SHORT).show();
                }
            }
        });
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Setting.this,"Clicked",Toast.LENGTH_SHORT).show();
            }
        });
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Setting.this,"Clicked",Toast.LENGTH_SHORT).show();
            }
        });
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Setting.this, Advice.class);
                startActivity(intent);
            }
        });
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Setting.this, Personal.class);
                startActivity(intent);
            }
        });
    }
}
