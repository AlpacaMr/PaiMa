package com.example.real.camera2test;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;



public class AccountPassword extends AppCompatActivity {
    EditText editText1,editText2,editText3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_password);
        Button button1 = findViewById(R.id.button1);
        Button button2 = findViewById(R.id.button2);
        EditText editText1 = findViewById(R.id.edit_new_password);
        EditText editText2 = findViewById(R.id.edit_old_password);
        EditText editText = findViewById(R.id.edit_password);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //返回账号与安全
                Intent intent = new Intent(AccountPassword.this, AccountSecurity.class);
                startActivity(intent);
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //确认修改密码
                Toast.makeText(AccountPassword.this, "修改成功", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(AccountPassword.this, LoginActivity.class);
                startActivity(intent);
            }
        });
    }
}
